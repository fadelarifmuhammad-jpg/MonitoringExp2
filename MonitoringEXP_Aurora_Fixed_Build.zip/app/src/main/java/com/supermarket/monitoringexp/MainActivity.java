package com.supermarket.monitoringexp;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.*;import android.graphics.drawable.*;import android.net.Uri;import android.os.*;import android.provider.OpenableColumns;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import androidx.core.content.FileProvider;import java.io.*;import java.nio.charset.StandardCharsets;import java.text.*;import java.util.*;import org.json.*;

public class MainActivity extends AppCompatActivity {
    Db db; LinearLayout content; TextView title,sub; int aqua=Color.rgb(54,217,232); int green=Color.rgb(99,245,177);
    int navy=Color.rgb(7,26,51), text=Color.rgb(16,42,67), muted=Color.rgb(107,130,154), surface=Color.rgb(245,248,252);
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Db(this);AlarmScheduler.ensureChannel(this);requestNotifications();showHome();handleIncoming(getIntent());}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIncoming(i);}
    void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},7);}
    GradientDrawable gradient(int... c){return new GradientDrawable(GradientDrawable.Orientation.TL_BR,c);}
    TextView tv(String s,float sp,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    TextView label(String s){TextView t=tv(s,13,muted);t.setPadding(0,4,0,4);return t;}
    LinearLayout root(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setBackgroundColor(surface);return r;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(14);return b;}
    TextView navItem(String icon,String name){TextView t=tv(icon+"\n"+name,11,muted);t.setGravity(Gravity.CENTER);t.setPadding(4,7,4,5);return t;}
    TextView stat(String icon,String name){TextView t=tv(icon+"  "+name+"\n0",12,Color.WHITE);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(14,12,8,12);t.setTypeface(null,1);return t;}
    void base(String page,String caption){LinearLayout r=root();LinearLayout head=new LinearLayout(this);head.setPadding(20,18,18,14);head.setGravity(Gravity.CENTER_VERTICAL);TextView back=tv("‹",34,Color.WHITE);head.addView(back,new LinearLayout.LayoutParams(44,56));LinearLayout hh=new LinearLayout(this);hh.setOrientation(LinearLayout.VERTICAL);title=tv(page,22,Color.WHITE);title.setTypeface(null,1);sub=tv(caption,12,Color.rgb(205,238,247));hh.addView(title);hh.addView(sub);head.addView(hh,new LinearLayout.LayoutParams(0,-2,1));head.setBackground(gradient(navy,Color.rgb(18,92,133),Color.rgb(75,46,131)));r.addView(head);back.setOnClickListener(v->showHome());content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(16,12,16,12);ScrollView sv=new ScrollView(this);sv.addView(content);r.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(r);}
    void showHome(){
        LinearLayout r=root();
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(20,20,20,20);hero.setBackground(gradient(navy,Color.rgb(12,104,143),Color.rgb(75,46,131)));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);ImageView logo=new ImageView(this);logo.setImageResource(com.supermarket.monitoringexp.R.drawable.ic_monitoring_exp);top.addView(logo,new LinearLayout.LayoutParams(58,58));LinearLayout ht=new LinearLayout(this);ht.setOrientation(LinearLayout.VERTICAL);TextView a=tv("MONITORING EXP",23,Color.WHITE);a.setTypeface(null,1);TextView b=tv("Pantau • Kelola • Ingat • Selalu",12,Color.rgb(206,244,248));ht.addView(a);ht.addView(b);top.addView(ht,new LinearLayout.LayoutParams(0,-2,1));TextView set=tv("⚙",26,Color.WHITE);top.addView(set,new LinearLayout.LayoutParams(42,58));hero.addView(top);TextView welcome=tv("Tetap satu langkah di depan masa expired.",14,Color.WHITE);welcome.setPadding(4,18,4,2);hero.addView(welcome);set.setOnClickListener(v->showSettings());r.addView(hero);
        LinearLayout stats=new LinearLayout(this);stats.setPadding(10,10,10,4);TextView s1=stat("📦","Total Produk"),s2=stat("🚨","Expired"),s3=stat("⏳","≤ 7 Hari"),s4=stat("📅","≤ 30 Hari");for(TextView s:new TextView[]{s1,s2,s3,s4}){s.setBackground(gradient(Color.rgb(17,86,119),Color.rgb(28,133,153)));stats.addView(s,new LinearLayout.LayoutParams(0,86,1));}r.addView(stats);updateStats(s1,s2,s3,s4);
        LinearLayout quick=new LinearLayout(this);quick.setPadding(10,6,10,8);Button scan=button("📷\nScan Barcode"),add=button("＋\nTambah Produk"),alarm=button("⏰\nBuat Alarm"),imp=button("📥\nImport File");for(Button x:new Button[]{scan,add,alarm,imp}){x.setTextColor(text);x.setTextSize(12);quick.addView(x,new LinearLayout.LayoutParams(0,78,1));}r.addView(quick);scan.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class).putExtra("scanNow",true)));add.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class)));alarm.setOnClickListener(v->startActivity(new Intent(this,AddAlarmActivity.class)));imp.setOnClickListener(v->openImportPicker());
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(16,6,16,6);TextView ih=tv("Pusat perhatian",18,text);ih.setTypeface(null,1);info.addView(ih);TextView desc=tv("Kelola produk, alarm, laporan, dan pekerjaan dari satu aplikasi.",13,muted);info.addView(desc);r.addView(info);
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setBackgroundColor(Color.WHITE);TextView n1=navItem("⌂","Beranda"),n2=navItem("▣","Produk"),n3=navItem("⏰","Alarm"),n4=navItem("☷","Laporan");for(TextView n:new TextView[]{n1,n2,n3,n4})nav.addView(n,new LinearLayout.LayoutParams(0,68,1));r.addView(nav);n1.setTextColor(aqua);n2.setOnClickListener(v->showProducts());n3.setOnClickListener(v->showAlarms());n4.setOnClickListener(v->showReports());setContentView(r);
    }
    void updateStats(TextView a,TextView b,TextView c,TextView d){int ex=0,s7=0,s30=0;for(Product p:db.all()){long x=days(p.expiry);if(x<0)ex++;else if(x<=7)s7++;else if(x<=30)s30++;}a.setText("📦  Total Produk\n"+db.all().size());b.setText("🚨  Expired\n"+ex);c.setText("⏳  ≤ 7 Hari\n"+s7);d.setText("📅  ≤ 30 Hari\n"+s30);}
    long days(String e){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);Date d=f.parse(e);Calendar end=Calendar.getInstance();end.setTime(d);end.set(Calendar.HOUR_OF_DAY,23);end.set(Calendar.MINUTE,59);end.set(Calendar.SECOND,59);Calendar now=Calendar.getInstance();return (end.getTimeInMillis()-now.getTimeInMillis())/86400000L;}catch(Exception x){return 999999;}}
    TextView productRow(Product p){long d=days(p.expiry);String status=d<0?"EXPIRED":d==0?"HARI INI":d+" hari lagi";int col=d<0?Color.rgb(220,50,80):d<=7?Color.rgb(210,145,0):Color.rgb(24,160,122);TextView row=tv(p.name+"\n"+(p.barcode==null||p.barcode.isEmpty()?"Tanpa barcode":"Barcode: "+p.barcode)+"\nExpired: "+p.expiry+"  •  "+status,14,text);row.setPadding(16,14,16,14);GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(18);bg.setStroke(1,Color.rgb(224,231,238));row.setBackground(bg);row.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_info_details,0,0,0);row.setCompoundDrawablePadding(12);row.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Hapus produk?").setMessage(p.name).setNegativeButton("Batal",null).setPositiveButton("Hapus",(d1,w)->{db.deleteProduct(p.id);showProducts();}).show();return true;});return row;}
    void showProducts(){base("Produk","Daftar produk dan tanggal expired");EditText search=new EditText(this);search.setHint("🔎 Cari nama atau barcode");search.setSingleLine();content.addView(search);Button scan=button("📷 Scan Barcode"),add=button("＋ Tambah Produk");LinearLayout actions=new LinearLayout(this);actions.addView(scan,new LinearLayout.LayoutParams(0,55,1));actions.addView(add,new LinearLayout.LayoutParams(0,55,1));content.addView(actions);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);content.addView(list);Runnable refresh=()->{list.removeAllViews();String q=search.getText().toString().trim();List<Product> ps=q.isEmpty()?db.all():db.search(q);for(Product p:ps){TextView row=productRow(p);list.addView(row,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));Space sp=new Space(this);list.addView(sp,new LinearLayout.LayoutParams(1,8));}};refresh.run();search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){refresh.run();}public void afterTextChanged(android.text.Editable e){}});scan.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class).putExtra("scanNow",true)));add.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class)));}
    void showAlarms(){
        base("Alarm","Alarm produk dan pengingat pekerjaan");
        Button add=button("＋ Buat Alarm Baru");
        content.addView(add);
        TextView hint=tv("Ketuk alarm untuk aktif/nonaktif. Tekan lama untuk menghapus.",12,muted);
        hint.setPadding(4,8,4,12);
        content.addView(hint);
        LinearLayout list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        content.addView(list);
        Runnable refresh=new Runnable(){
            @Override public void run(){
                list.removeAllViews();
                for(AlarmModel a:db.alarms()){
                    TextView r=tv((a.enabled?"● ":"○ ")+new SimpleDateFormat("dd MMM yyyy • HH:mm",new Locale("id","ID")).format(new Date(a.triggerAt))+"\n"+a.title,15,text);
                    r.setPadding(16,14,16,14);
                    GradientDrawable g=new GradientDrawable();
                    g.setColor(Color.WHITE);
                    g.setCornerRadius(18);
                    g.setStroke(1,Color.rgb(224,231,238));
                    r.setBackground(g);
                    r.setOnClickListener(v->{
                        if(a.enabled){
                            AlarmScheduler.cancel(MainActivity.this,a.id);
                            db.setAlarmEnabled(a.id,false);
                        }else{
                            db.setAlarmEnabled(a.id,true);
                            AlarmScheduler.schedule(MainActivity.this,a.id,a.triggerAt,a.title);
                        }
                        run();
                    });
                    r.setOnLongClickListener(v->{
                        new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Hapus alarm?")
                            .setMessage(a.title)
                            .setNegativeButton("Batal",null)
                            .setPositiveButton("Hapus",(d,w)->{
                                AlarmScheduler.cancel(MainActivity.this,a.id);
                                db.deleteAlarm(a.id);
                                run();
                            }).show();
                        return true;
                    });
                    list.addView(r,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));
                    Space sp=new Space(MainActivity.this);
                    list.addView(sp,new LinearLayout.LayoutParams(1,8));
                }
            }
        };
        refresh.run();
        add.setOnClickListener(v->startActivity(new Intent(this,AddAlarmActivity.class)));
    }
    void showReports(){base("Laporan","Ekspor, backup, dan import data Monitoring EXP");TextView hero=tv("📧  Laporan membantu Anda mengambil tindakan lebih cepat.",17,text);hero.setPadding(8,8,8,20);content.addView(hero);Button email=button("📧 Kirim Produk Expired via Email"),csv=button("↓ Export Semua Produk ke CSV"),backup=button("☁ Backup Data JSON"),imp=button("📥 Import CSV / JSON dari Email");content.addView(email);content.addView(csv);content.addView(backup);content.addView(imp);TextView hint=tv("Import dapat dilakukan langsung dari lampiran email dengan memilih Open with / Buka dengan → Monitoring EXP. Anda juga bisa memilih file dari perangkat.",13,muted);hint.setPadding(8,10,8,18);content.addView(hint);TextView work=tv("\nWORK ASSISTANT\nGunakan alarm untuk deadline kerja, pengecekan stok, rapat, atau tugas berulang.",15,muted);content.addView(work);email.setOnClickListener(v->emailExpired());csv.setOnClickListener(v->exportCsv());backup.setOnClickListener(v->backupJson());imp.setOnClickListener(v->openImportPicker());}
    void showSettings(){base("Pengaturan","Preferensi Monitoring EXP");TextView logo=tv("MONITORING EXP\nAurora Edition",25,text);logo.setTypeface(null,1);logo.setPadding(8,12,8,18);content.addView(logo);Button alarm=button("🔔 Pengaturan Notifikasi & Alarm"),exact=button("⏱ Izinkan Alarm Tepat Waktu"),about=button("ℹ Tentang Aplikasi");content.addView(alarm);content.addView(exact);content.addView(about);alarm.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=33)requestNotifications();Toast.makeText(this,"Notifikasi dicek. Pastikan suara & getar aktif di pengaturan Android.",Toast.LENGTH_LONG).show();});exact.setOnClickListener(v->{if(!AlarmScheduler.exactAllowed(this)){AlarmScheduler.openExactAlarmSettings(this);}else Toast.makeText(this,"Alarm tepat waktu sudah diizinkan.",Toast.LENGTH_SHORT).show();});about.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Monitoring EXP").setMessage("Versi 3.0 Aurora\n\nPantau • Kelola • Ingat • Selalu\n\nAplikasi monitoring expired dengan barcode, alarm, notifikasi, laporan, dan backup.").setPositiveButton("OK",null).show());}
    static final int REQ_IMPORT=901;
    void openImportPicker(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/comma-separated-values","application/json","text/plain","application/octet-stream"});startActivityForResult(i,REQ_IMPORT);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==REQ_IMPORT&&resultCode==RESULT_OK&&data!=null)importUri(data.getData());}
    void handleIncoming(Intent i){if(i==null)return;String a=i.getAction();Uri u=i.getData();if(Intent.ACTION_SEND.equals(a)){Object x=i.getParcelableExtra(Intent.EXTRA_STREAM);if(x instanceof Uri)u=(Uri)x;}final Uri incoming=u;if(incoming!=null&&(Intent.ACTION_VIEW.equals(a)||Intent.ACTION_SEND.equals(a))){new Handler().postDelayed(()->importUri(incoming),450);}}
    void importUri(Uri uri){
        if(uri==null)return;try{
            String name=getName(uri);InputStream in=getContentResolver().openInputStream(uri);if(in==null)throw new IOException("File tidak dapat dibuka");StringBuilder sb=new StringBuilder();BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));String line;while((line=r.readLine())!=null)sb.append(line).append('\n');r.close();String raw=sb.toString().trim();
            int added=0,updated=0; if(raw.startsWith("[")){JSONArray arr=new JSONArray(raw);for(int i=0;i<arr.length();i++){JSONObject o=arr.getJSONObject(i);String b=o.optString("barcode","").trim(),n=o.optString("name",o.optString("nama","")).trim(),e=o.optString("expiry",o.optString("expired","")).trim();if(validRow(b,n,e)){boolean existed=findBarcode(b);long id=db.upsert(b,n,e);scheduleImported(id,n,e);if(existed)updated++;else added++;}}}else{String[] lines=raw.split("\\r?\\n");for(int i=0;i<lines.length;i++){if(lines[i].trim().isEmpty())continue;List<String> a=Csv.parseLine(lines[i]);if(i==0&&isHeader(a))continue;if(a.size()<3)continue;String b=a.get(0).trim(),n=a.get(1).trim(),e=a.get(2).trim();if(validRow(b,n,e)){boolean existed=findBarcode(b);long id=db.upsert(b,n,e);scheduleImported(id,n,e);if(existed)updated++;else added++;}}}
            showHome();new AlertDialog.Builder(this).setTitle("Import selesai ✓").setMessage("File: "+name+"\n\nProduk baru: "+added+"\nProduk diperbarui: "+updated+"\n\nAlarm expired otomatis dijadwalkan ulang.").setPositiveButton("Lihat Produk",(d,w)->showProducts()).setNegativeButton("Tutup",null).show();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Import gagal").setMessage("File belum didukung atau formatnya tidak valid.\n\n"+e.getMessage()).setPositiveButton("OK",null).show();}
    }
    boolean isHeader(List<String> a){if(a.isEmpty())return false;String x=a.get(0).toLowerCase(Locale.US);return x.contains("barcode")||x.contains("kode");}
    boolean validRow(String b,String n,String e){if(n.isEmpty()||e.isEmpty())return false;try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);f.parse(e);return true;}catch(Exception x){return false;}}
    boolean findBarcode(String b){if(b==null||b.isEmpty())return false;for(Product p:db.all())if(b.equals(p.barcode))return true;return false;}
    void scheduleImported(long id,String n,String e){try{Date ed=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e);db.clearProductAlarms(id);Calendar c=Calendar.getInstance();c.setTime(ed);c.set(Calendar.HOUR_OF_DAY,8);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);int[] offsets={30,7,1,0};for(int off:offsets){Calendar a=(Calendar)c.clone();a.add(Calendar.DAY_OF_YEAR,-off);long at=a.getTimeInMillis();if(at>System.currentTimeMillis()){long aid=db.addAlarm((off==0?"🚨 EXPIRED: ":"⏰ H-"+off+": ")+n,at,id);AlarmScheduler.schedule(this,aid,at,(off==0?"EXPIRED: ":"H-"+off+": ")+n);}}}catch(Exception ignored){}}
    String getName(Uri u){try{android.database.Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&ix>=0){String n=c.getString(ix);c.close();return n;}c.close();}}catch(Exception ignored){}return String.valueOf(u);}
    void emailExpired(){ArrayList<Product> ex=new ArrayList<>();for(Product p:db.all())if(days(p.expiry)<0)ex.add(p);if(ex.isEmpty()){Toast.makeText(this,"Tidak ada produk expired.",Toast.LENGTH_SHORT).show();return;}try{File f=new File(getCacheDir(),"Produk_Expired.csv");BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8));w.write("Barcode,Nama Produk,Tanggal Expired\n");for(Product p:ex)w.write(Csv.esc(p.barcode)+","+Csv.esc(p.name)+","+Csv.esc(p.expiry)+"\n");w.close();share(f,"text/csv","Laporan Produk Expired","Terlampir laporan produk expired.");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    void exportCsv(){try{File f=new File(getExternalFilesDir(null),"MonitoringEXP.csv");BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8));w.write("Barcode,Nama Produk,Tanggal Expired\n");for(Product p:db.all())w.write(Csv.esc(p.barcode)+","+Csv.esc(p.name)+","+Csv.esc(p.expiry)+"\n");w.close();share(f,"text/csv","Monitoring EXP CSV","");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    void backupJson(){try{File f=new File(getExternalFilesDir(null),"MonitoringEXP_Backup.json");BufferedWriter w=new BufferedWriter(new FileWriter(f));w.write("[\n");int i=0;for(Product p:db.all()){if(i++>0)w.write(",\n");w.write("{\"barcode\":\""+json(p.barcode)+"\",\"name\":\""+json(p.name)+"\",\"expiry\":\""+json(p.expiry)+"\"}");}w.write("\n]");w.close();share(f,"application/json","Backup Monitoring EXP","");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    String json(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"");}
    void share(File f,String type,String subject,String body){Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_SUBJECT,subject);if(!body.isEmpty())i.putExtra(Intent.EXTRA_TEXT,body);i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Kirim / Bagikan"));}
    @Override protected void onResume(){super.onResume();if(db!=null){AlarmScheduler.ensureChannel(this);}}
}
