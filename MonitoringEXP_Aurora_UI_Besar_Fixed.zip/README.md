# Monitoring EXP — Aurora Edition 4.0

Aplikasi Android untuk memantau tanggal expired produk, scan barcode, membuat alarm, serta export/import data.

## Fitur utama
- Dashboard Monitoring EXP
- Produk + barcode + tanggal expired
- Google Code Scanner
- Alarm otomatis H-30, H-7, H-1, dan Hari H pukul 08:00
- Alarm custom tanggal + jam
- Notifikasi prioritas tinggi, suara alarm, dan getar
- Import CSV/JSON dari file atau lampiran email dengan **Buka dengan → Monitoring EXP**
- Export CSV
- Backup JSON
- Kirim laporan produk expired melalui email/share
- Penjadwalan ulang alarm setelah restart/perubahan waktu

## Build GitHub Actions
Workflow berada di `.github/workflows/android.yml` dan dijalankan saat push ke `main`/`master` atau secara manual melalui **Actions → Monitoring EXP APK → Run workflow**.

APK debug tersedia di bagian **Artifacts** setelah build berhasil.

## Catatan Kotlin
Dependensi scanner dapat membawa Kotlin stdlib JDK7/JDK8 lama. Proyek ini secara eksplisit mengecualikan kedua artefak tersebut agar tidak terjadi error `Duplicate class`.

## Izin Android
- Android 13+: izinkan notifikasi.
- Android 12+: izinkan **Alarms & reminders** bila ingin alarm tepat waktu.
- Izin kamera diperlukan ketika scanner digunakan.
