package com.supermarket.monitoringexp;
public class Product {
    public long id; public String barcode, name, expiry;
    public Product(long id,String barcode,String name,String expiry){this.id=id;this.barcode=barcode;this.name=name;this.expiry=expiry;}
}
