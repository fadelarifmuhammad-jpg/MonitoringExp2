package com.supermarket.monitoringexp;

import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.os.*;import android.view.*;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;import java.text.*;import java.util.*;

public class AddProductActivity extends AppCompatActivity {
    EditText barcode,name;TextView expiry;Db db;int text=Color.rgb(16,42,67);int muted=Color.rgb(107,130,154);
    public void onCreate(Bundle b){super.onCreate(b);db=new Db(this);AlarmScheduler.ensureChannel(this);build();if(getIntent().getBooleanExtra("scanNow",false))new Handler().postDelayed(this::scan,350);}
    GradientDrawable fieldBg(){GradientDrawable g=new GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(16);g.setStroke(1,Color.rgb(220,228,237));return g;}
    TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(muted);t.setTextSize(13);t.setPadding(3,12,3,5);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(14);return b;}
    public void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(245,248,252));
        TextView head=label("‹   TAMBAH PRODUK");head.setTextSize(22);head.setTextColor(Color.WHITE);head.setTypeface(null,1);head.setPadding(18,20,18,20);head.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(7,26,51),Color.rgb(18,119,184),Color.rgb(75,46,131)}));root.addView(head);head.setOnClickListener(v->finish());
        LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(18,12,18,20);ScrollView sv=new ScrollView(this);sv.addView(body);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        body.addView(label("BARCODE"));LinearLayout br=new LinearLayout(this);barcode=new EditText(this);barcode.setSingleLine();barcode.setHint("Scan atau ketik barcode");barcode.setBackground(fieldBg());barcode.setPadding(16,0,10,0);Button sc=btn("📷 Scan");br.addView(barcode,new LinearLayout.LayoutParams(0,56,1));br.addView(sc,new LinearLayout.LayoutParams(110,56));body.addView(br);
        body.addView(label("NAMA PRODUK"));name=new EditText(this);name.setSingleLine();name.setHint("Contoh: Susu UHT ABC");name.setBackground(fieldBg());name.setPadding(16,0,16,0);body.addView(name,new LinearLayout.LayoutParams(-1,56));
        body.addView(label("TANGGAL EXPIRED"));expiry=new TextView(this);expiry.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));expiry.setTextSize(16);expiry.setTextColor(text);expiry.setGravity(Gravity.CENTER_VERTICAL);expiry.setPadding(16,0,16,0);expiry.setBackground(fieldBg());body.addView(expiry,new LinearLayout.LayoutParams(-1,56));
        TextView info=label("Alarm otomatis: H-30 • H-7 • H-1 • Hari H (pukul 08:00). Jika tanggal sudah lewat, alarm tidak dijadwalkan.");info.setTextSize(12);info.setPadding(5,14,5,16);body.addView(info);
        Button save=btn("✓  Simpan Produk & Jadwalkan Alarm");body.addView(save,new LinearLayout.LayoutParams(-1,58));setContentView(root);
        sc.setOnClickListener(v->scan());expiry.setOnClickListener(v->pickDate());save.setOnClickListener(v->save());
    }
    void pickDate(){Calendar c=Calendar.getInstance();new DatePickerDialog(this,(v,y,m,d)->expiry.setText(String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d)),c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void scan(){GmsBarcodeScanning.getClient(this).startScan().addOnSuccessListener(x->{if(x.getRawValue()!=null)barcode.setText(x.getRawValue());}).addOnFailureListener(e->Toast.makeText(this,"Scanner gagal: "+e.getMessage(),Toast.LENGTH_LONG).show());}
    void save(){String b=barcode.getText().toString().trim(),n=name.getText().toString().trim(),e=expiry.getText().toString().trim();if(n.isEmpty()){name.setError("Nama produk wajib diisi");return;}try{Date ed=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e);long pid=db.add(b,n,e);Calendar c=Calendar.getInstance();c.setTime(ed);c.set(Calendar.HOUR_OF_DAY,8);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);int[] offsets={30,7,1,0};for(int off:offsets){Calendar a=(Calendar)c.clone();a.add(Calendar.DAY_OF_YEAR,-off);long at=a.getTimeInMillis();if(at>System.currentTimeMillis()){long aid=db.addAlarm((off==0?"🚨 EXPIRED: ":"⏰ H-"+off+": ")+n,at,pid);AlarmScheduler.schedule(this,aid,at,(off==0?"EXPIRED: ":"H-"+off+": ")+n);}}Toast.makeText(this,"Produk disimpan dan alarm dijadwalkan.",Toast.LENGTH_LONG).show();finish();}catch(Exception x){Toast.makeText(this,"Tanggal harus YYYY-MM-DD.",Toast.LENGTH_SHORT).show();}}
}
