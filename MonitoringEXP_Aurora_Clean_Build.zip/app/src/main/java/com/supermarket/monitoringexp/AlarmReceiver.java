package com.supermarket.monitoringexp;

import android.app.*;import android.content.*;import android.media.*;import android.os.*;import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {
    public void onReceive(Context c,Intent i){
        AlarmScheduler.ensureChannel(c);
        String title=i.getStringExtra("title");if(title==null)title="Monitoring EXP";
        int id=i.getIntExtra("alarmId",(int)(System.currentTimeMillis()%1000000));
        Intent full=new Intent(c,AlarmActivity.class).putExtra("title",title).putExtra("alarmId",id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent fp=PendingIntent.getActivity(c,id,full,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,AlarmScheduler.CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("🚨 "+title)
            .setContentText("Alarm Monitoring EXP berbunyi sekarang.").setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM).setAutoCancel(true).setOngoing(false).setFullScreenIntent(fp,true).setContentIntent(fp);
        if(Build.VERSION.SDK_INT<33||c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")==0)
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());
        try{UriAlarm.play(c);}catch(Exception ignored){}
        ((android.os.Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE)).vibrate(Build.VERSION.SDK_INT>=26?VibrationEffect.createWaveform(new long[]{0,700,500,700,500,1200},-1):new long[]{0,700,500,700,500,1200},-1);
    }
    static class UriAlarm{static void play(Context c){UriAlarmHolder.start(c);}}
    static class UriAlarmHolder{
        static MediaPlayer player;
        static void start(Context c){stop();android.net.Uri u=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);if(u==null)u=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);player=MediaPlayer.create(c,u);if(player!=null){player.setLooping(true);player.start();}}
        static void stop(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}}
    }
}
